<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendador de tarefas</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="fontawesome-free-6.7.2-web\css\all.css">
</head>
<body>

    <div class="container mt-2">
        <div class="row justify-content-center">
            <div class="col-12 col-sm-10 col-md-8">
                <div class="card shadow">
                    <div class="card-header">
                        <h4 class="text-center text-dark">
                            Sistema Agendador de Tarefas
                        </h4>
                    </div>
                    <form method="post">
                        <div class="card-body">
                            <div class="form-group row">
                                <div class="col-12 col-sm-3 col-md-2">
                                    <label>Data/Hora</label>
                                    <input type="datetime" name="date" id="date" class="form-control">
                                </div>
                                <div class="col-12 col-sm-9 col-md-10">
                                    <label>Tarefa</label>
                                    <input type="text" name="task" id="task" class="form-control">
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Descrição</label>
                                <input type="text" name="description" id="description" class="form-control">
                            </div>                       
                        </div>
                        <div class="card-footer">
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary btn-block btn-lg">
                                    <i class="fa-solid fa-list-check"></i> Adicionar tarefa
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="row p-3 mt-5">
            <div class="col-12">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col" class="text-center">Data/Hora</th>
                                <th scope="col" class="text-center">Tarefa</th>
                                <th scope="col" class="text-center">Descrição</th>
                                <th scope="col" class="text-center">Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="text-center">00/00/00 00:00</td>
                                <td class="text-center">Test Teste Test</td>
                                <td class="text-center">Lorem, ipsum dolor sit amet consectetur adipisicing elit.</td>
                                <td class="text-center">
                                    <button class="btn btn-success"><i class="fa-solid fa-square-check"></i></button>
                                    <button class="btn btn-danger"><i class="fa-solid fa-trash-can"></i></button>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-center">00/00/00 00:00</td>
                                <td class="text-center">Test Teste Test</td>
                                <td class="text-center">Lorem, ipsum dolor sit amet consectetur adipisicing elit.</td>
                                <td class="text-center">
                                    <button class="btn btn-success"><i class="fa-solid fa-square-check"></i></button>
                                    <button class="btn btn-danger"><i class="fa-solid fa-trash-can"></i></button>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-center">00/00/00 00:00</td>
                                <td class="text-center">Test Teste Test</td>
                                <td class="text-center">Lorem, ipsum dolor sit amet consectetur adipisicing elit.</td>
                                <td class="text-center">
                                    <button class="btn btn-success"><i class="fa-solid fa-square-check"></i></button>
                                    <button class="btn btn-danger"><i class="fa-solid fa-trash-can"></i></button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
</body>
</html>